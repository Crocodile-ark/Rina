------------------------------------------------------------------------
Original MOD: [meta] Curve ver2.0
For details: http://metagraphy.blog.fc2.com/blog-entry-69.html
------------------------------------------------------------------------

Info:
- This is color curve data and graphics setting file that changes the contrast of honey select.
- Scene data (scene.png) used for adjustment is also included.

Installation: 
- Place the included folder into your HoneySelect directory. 

Required plug-in:
- HSParty Graphic Patch ver.170619 : https://mega.nz/#F!yBdEFBDJ!PGfCcFPPYgxDDOFXLHRXUw

Important points:
- Plasticmind's "HSParty Graphic Patch" is required to use this mod.
- This mod does not operate in the environment where "HS linear rendering experiment (LRE)" is installed.
- Be sure to back up /UserDate/GraphicSetting/StudioNeoConfig.xml before trying.

Update:
2019.11.01 --- ver.2.0 Added a new curve with expanded dynamic range
2018.03.29 --- ver.1.0 First Release


Author:metagraphy
blog:http://metagraphy.blog.fc2.com/
patreon:https://www.patreon.com/metagraphy
tiwtter:https://twitter.com/metagraphyworks
pixiv:https://www.pixiv.net/member.php?id=27097762

---------------------------------------------------------------

Have Hun!