---
name: 'Feature request: Device'
about: I want a device type integrated into LoveMachine.
title: ''
labels: ''
assignees: ''

---

> What is an example of this type of device? (Provide link to iostindex.com entry or product page.)

[answer here]

> Do you volunteer to test this feature if it gets implemented? (I take no responsibility for accidents.)

[answer here]
