---
name: 'Feature request: Game'
about: I want a game added to LoveMachine.
title: ''
labels: ''
assignees: ''

---

> Is this a Unity 3D game? (I can't support other types of games.)

[answer here]

> Are there any other BepInEx mods for this game? (If yes, provide links.)

[answer here]

> Where can I download this game?
(If it's a paid game, preferably provide a DLsite link. Piracy is not allowed on GitHub.)

[answer here]
