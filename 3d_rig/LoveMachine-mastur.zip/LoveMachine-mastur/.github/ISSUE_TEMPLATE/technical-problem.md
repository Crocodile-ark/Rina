---
name: Technical problem
about: I need help in using the plugin
title: ''
labels: ''
assignees: ''

---

> Please read the Troubleshooting page before opening an issue. Your problem might already be answered there.

[I have read it, and it didn't help]

> Please write down the title and version number of the game and the list of DLCs if you have any installed.

[answer here]

> Describe the problem. Make sure to attach your BepinEx\LogOutput.log file (or in some games, the output_log.txt file in the game directory).

[answer here]
