﻿using BepInEx;
using LoveMachine.Core;
using LoveMachine.Core.NonPortable;

namespace LoveMachine.SCH;

[BepInPlugin(Globals.GUID, Globals.PluginName, Globals.Version)]
internal class Plugin : LoveMachinePlugin<SolasCityHeroesGame>
{ }
