﻿using Il2CppInterop.Runtime.Attributes;

namespace LoveMachine.Core.NonPortable;

public class HideFromIl2Cpp: HideFromIl2CppAttribute
{ }