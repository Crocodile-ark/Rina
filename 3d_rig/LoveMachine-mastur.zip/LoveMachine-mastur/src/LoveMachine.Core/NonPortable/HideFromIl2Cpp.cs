﻿using System;

namespace LoveMachine.Core.NonPortable
{
    internal class HideFromIl2Cpp : Attribute
    { }
}