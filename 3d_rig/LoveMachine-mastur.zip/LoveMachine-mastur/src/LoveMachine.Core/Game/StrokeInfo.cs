﻿namespace LoveMachine.Core.Game
{
    public struct StrokeInfo
    {
        public float Amplitude { get; set; }
        public float DurationSecs { get; set; }
        public float Completion { get; set; }
    }
}