﻿namespace LoveMachine.Core.Common
{
    public enum Bone
    {
        Auto, Vagina, Anus, Mouth, LeftHand, RightHand, LeftFoot, RightFoot,
        LeftBreast, RightBreast, LeftButt, RightButt
    }
}