﻿namespace LoveMachine.Core.Common
{
    public enum POV
    {
        Balanced, Male, Female
    }
}